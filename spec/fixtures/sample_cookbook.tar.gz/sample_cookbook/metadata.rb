name             'sample_cookbook'
maintainer       'MadGlory'
maintainer_email 'YOUR_EMAIL'
license          'All rights reserved'
description      'Installs/Configures sample_cookbook'
long_description 'Installs/Configures sample_cookbook'
version          '1.2.3'

depends 'yum', '> 3.0.0'
